<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
require_once 'auth.php'; // Assuming we create auth.php in admin folder

require 'config.php'; // contains $mysqli = new mysqli(...);
$error = '';


// Ensure error reporting won't expose sensitive data in production
error_reporting(0);

// Check if the cookie exists and has the right value
if (
    !isset($_COOKIE['auth_role']) || 
    ($_COOKIE['auth_role'] !== 'admin' && $_COOKIE['auth_role'] !== 'market')
) {
    echo "No access";
    exit; // Stop processing the rest of the page
}

// If the user passes the check, the rest of your page code runs below...

// If cookie is set — user is authenticated

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CCTV Quote Calculator</title>
    <link rel="stylesheet" href="css/styles.css">
    
   
</head>
<body class="quote">
    <div class="controls">
        <div class="logo-section">
                <a href="/" class="custom-logo-link" rel="home" aria-current="page">
                    <img width="200" height="40" src="https://smartronic.online/content/uploads/2025/01/smarthome-black2.svg" class="custom-logo" alt="Smartronic | CCTV with Free Installation | Smart Home Automation" decoding="async">
                </a>
            
            </div>
 
        <?php
        echo "<h2>Hello, " . $_COOKIE['auth_name'] . "!</h2>";
        ?>
         
     

        </div>
    </div>
    <div class="container">
        

        
        <label>Manual:</label><input type="checkbox" value="on" name="manual" id="manual" onchange="updateDVRSelection(); calculateTotal();"/> 
        <div class="row">
            <div class="column">
                <input type="hidden" name="idno" id="idno" />
                <label>Hard Disk:</label>
                <select id="hardDisk" onchange="calculateTotal()">
                    <option value="0">Select</option>
                    <option value="1000" selected>Const 500 GB (2Yr) - ₹1000</option>
                    <option value="2750">Const 1TB (2Yr) - ₹2750</option>
                    <option value="3650">Const 2TB (2Yr) - ₹3650</option>
                    <option value="5250">Const 4TB (2Yr) - ₹5250</option>
                    <option value="850">500 GB (1Yr) - ₹850</option>
                    <option value="1950">1TB (1Yr) - ₹1950</option>
                    <option value="3600">1TB (3Yr) - ₹3600</option>
                    <option value="2850">2TB (1Yr) - ₹2800</option>
                    <option value="4050">2TB (3Yr) - ₹4050</option>
                    <option value="3250">3TB (1Yr) - ₹3250</option>
                    <option value="5250">4TB (1Yr) - ₹5250</option>
                    <option value="6650">4TB (3Yr) - ₹6650</option>
                </select>

                <label>Camera Type:</label>
                <select id="camera" onchange="updateDVRSelection(); calculateTotal();">
                    <option value="0">Select</option>
                    <!--
                    <option value="1400" data-type="5 mp">5 MP Color Night 3K - ₹1400</option>
                    -->
                    <option value="2180" data-type="5 mp">5 MP Color Night 3K - ₹1980</option>
                    <option value="1450" data-type="5 mp">5 MP HYBID Color Night 3K - ₹1450</option>
                    <option value="1150" data-type="5 mp">5 MP Normal Night - ₹1150</option>
                    <option value="1800" data-type="2 mp">2 MP Color Night - ₹1600</option>
                    <option value="1250" data-type="2 mp">2 MP HYBID Color Night- ₹1250</option>
                    <!--
                    <option value="980" data-type="2 mp">2 MP Color Night - ₹980</option>
                    -->
                    <option value="825" data-type="2 mp">2 MP Normal Night Mic - ₹825</option>
                    <option value="800" data-type="2 mp">2 MP Normal Night - ₹720</option>

                    <option value="2500" data-type="2 mp NVR">NVR 2 MP - ₹2700</option>
                    <option value="2650" data-type="2 mp NVR">NVR 4 MP - ₹3150</option>
                    <option value="2650" data-type="2 mp NVR">NVR 4 MP - ₹2150</option>
                    <option value="4850" data-type="2 mp NVR">NVR 6 MP - ₹4850</option>
                    
                </select>

                <label>Number of Cameras:</label>
                <input type="number" id="numCameras" value="1" min="1" onchange="updateDVRSelection(); calculateTotal();">

                <label>DVR Type:</label>
                <select id="dvr" onchange="calculateTotal()">
                </select>

                <label>DVR SMPS / NVR POE:</label>
                <select id="smps" onchange="calculateTotal()"> 
                    <option value="400">SMPS 400 - ₹400</option>
                    <option value="750">SMPS 750 - ₹750</option>
                </select>

           
                
                <input type="text" id="poe" value="0" />
               

                <label>Cable 90 Meters:</label>
                <select id="cable" onchange="calculateTotal()">
                    <option value="650" >Local ₹650</option>
                    <option value="1000" selected>DLINK ₹1000</option>
                    <option value="1600" >CP Plus Cat6 ₹1600</option>
                </select>
                
                <label>Profit Margin (%):</label>
                <input type="number" id="profitMargin" value="60" min="0" onchange="calculateTotal()">
            </div>
        
            <div class="column">
                <div id="breakdown"></div>
                
            </div>
        </div>
        <h2></h2>
        <div class="row">
            <div class="row-container">
                <div class="column">
                    <label for="perCam">Installation per CAM: <span id="perCamValue">100</span></label>
                    <input type="range" min="400" max="900" step="50" name="perCam" id="perCam" value="600" onchange="calculateTotal()" oninput="updateProfitValue()"/>
                </div>
                <div class="column"> 
                    <label for="limitedProfit">Profit: <span id="limitedProfitValue">100</span></label>
                    <input type="range" min="100" max="10000" step="100" name="profit" id="limitedProfit" value="3000" onchange="calculateTotal()" oninput="updateProfitValue()"/>
                </div>
                
            </div>
        </div>
        <h2>WhatsApp Message</h2>
        <div class="row whatsapp-message-box">
           
        <div class="row-container">
            <div class="column">
                <label>Name:</label>
                <input type="text" name="name" id="name" onchange="calculateTotal()"/>
            </div>
            <div class="column">  
                <label>WhatsApp:</label>
                <input type="text" name="pnumber" id="pnumber" onchange="calculateTotal()"/>
            </div>
            <div class="column">
                <button class="whatsapp-button" onclick="sendWhatsAppMessage()">Send via WhatsApp</button>
            </div>
        </div>


            <div class="tab-container">
                <div class="tab-buttons">
                    <button class="tab-btn active" onclick="openTab(event, 'whatsappMessage')">Greeting + 1st Quote</button>
                    <button class="tab-btn" onclick="openTab(event, 'mess-1')">2nd Quote</button>
                    <button class="tab-btn" onclick="openTab(event, 'mess-2')">3rd Quote</button>
                    <button class="tab-btn" onclick="openTab(event, 'mess-3')">Message 3</button>
                    <button class="tab-btn" onclick="openTab(event, 'mess-4')">Message 4</button>
                </div>

                <div class="tab-content active" id="whatsappMessage">
                    <button onclick="copyToClipboard('whatsappMessage')">Copy to Clipboard</button>
                    <div>WhatsApp Message Content Here</div>
                </div>

                <div class="tab-content" id="mess-1">
                    <button onclick="copyToClipboard('mess-1')">Copy to Clipboard</button>
                    <div>Message 1 Content Here</div>
                </div>

                <div class="tab-content" id="mess-2">
                    <button onclick="copyToClipboard('mess-2')">Copy to Clipboard</button>
                    <div>Message 2 Content Here</div>
                </div>

                <div class="tab-content" id="mess-3">
                    <button onclick="copyToClipboard('mess-3')">Copy to Clipboard</button>
                    <div>Message 3 Content Here</div>
                </div>

                <div class="tab-content" id="mess-4">
                    <button onclick="copyToClipboard('mess-4')">Copy to Clipboard</button>
                    <div>Message 4 Content Here</div>
                </div>
            </div>


        </div>
        <?php
            $js_suffix = isset($_GET['js']) ? basename($_GET['js']) : '';
            $js_file = $js_suffix ? "js/scripts.js" : 'js/scripts_may2025';
        ?>
<script src="js/scripts_may2025.js"></script>
</body> 
</html>
