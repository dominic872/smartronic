<?php
require 'config.php';

$date = $_GET['date'] ?? '';
header('Content-Type: application/json');

if (!$date || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    echo json_encode(['success' => false, 'message' => 'Invalid date']);
    exit;
}

$stmt = $mysqli->prepare("
    SELECT users.fullname, leaves.reason 
    FROM leaves 
    JOIN users ON users.id = leaves.user_id
    WHERE leave_date = ?
");
$stmt->bind_param('s', $date);
$stmt->execute();
$result = $stmt->get_result();

$leaves = [];
while ($row = $result->fetch_assoc()) {
    $leaves[] = ['fullname' => $row['fullname'], 'reason' => $row['reason']];
}

echo json_encode(['success' => true, 'leaves' => $leaves]);
