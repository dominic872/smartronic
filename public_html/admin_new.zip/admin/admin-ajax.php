<?php

// Database connection parameters
$host = '127.0.0.1:3306';
$username = 'u398852039_smartronic';
$password = 'Chennai@40!';
$database = 'u398852039_smartronic';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'data' => 'Database connection failed: ' . $conn->connect_error]));
}

function getMonthCode() {
    // Create DateTime object in IST
    $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
    $month = (int) $date->format('n'); // 1 = January, 2 = February, ..., 12 = December

    $monthLetters = [
        1 => 'J',  // JAN
        2 => 'F',  // FEB
        3 => 'C',  // MAR
        4 => 'R',  // APR
        5 => 'M',  // MAY
        6 => 'U',  // JUN
        7 => 'L',  // JUL
        8 => 'G',  // AUG
        9 => 'S',  // SEP
        10 => 'O', // OCT
        11 => 'N', // NOV
        12 => 'D'  // DEC
    ];

    return $monthLetters[$month] ?? 'X'; // fallback to 'X' if not found
}

// Google ads campaign tracking

$gads = $_POST['gads'] ?? null;

$map = [
    "DemandGen2025-07-31" => "DG",
    "GetLeads" => "GL"
];

$label = $map[$gads] ?? "Q";

// Check if the AJAX request contains the expected action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'crf_save_form_data') {

    // Sanitize input values
    $num_cameras = $conn->real_escape_string($_POST['num_cameras'] ?? '');
    $dvr_type = $conn->real_escape_string($_POST['dvr_type'] ?? '');
    $hdd_size = $conn->real_escape_string($_POST['hdd_size'] ?? '');
    $camera_resolution = $conn->real_escape_string($_POST['camera_resolution'] ?? '');
    $whatsapp_number = $conn->real_escape_string($_POST['whatsapp_number'] ?? '');

    // Validate required fields
    if (empty($num_cameras) || empty($dvr_type) || empty($hdd_size) || empty($camera_resolution) || empty($whatsapp_number)) {
        echo json_encode(['success' => false, 'data' => 'All fields are required.']);
        exit;
    }

    // Insert data into the database using prepared statements
    $stmt = $conn->prepare(
        "INSERT INTO wp_cctv_requirements (num_cameras, dvr_type, hdd_size, camera_resolution, whatsapp_number) 
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param('sssss', $num_cameras, $dvr_type, $hdd_size, $camera_resolution, $whatsapp_number);

    if ($stmt->execute()) {
       
        
        // Data saved successfully
        //echo json_encode(['success' => true, 'data' => 'Data saved successfully.']);
        // Get visitor details
        $ip_address = $_SERVER['REMOTE_ADDR'];

        // Fetch location details using IP
        $ip_info = json_decode(file_get_contents("http://ip-api.com/json/$ip_address"), true);
        $region = $ip_info['regionName'] ?? 'Unknown';
        $country = $ip_info['country'] ?? 'Unknown';
        $city = $ip_info['city'] ?? 'Unknown';

        $user_vals = "$ip_address | $region | $country | $city ";

        // Email settings
        $to = "hello@smartronic.online"; // Replace with your email address
        $subject = "$whatsapp_number | $num_cameras | $dvr_type | $hdd_size | $camera_resolution";
        $headers = "From: hello@smartronic.online\r\n";
        $headers .= "Reply-To: hello@smartronic.online\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

        // Email body
        $body = "CCTV Requirement Details:\n";
        $body .= "Number of Cameras: $num_cameras\n";
        $body .= "DVR Type: $dvr_type\n";
        $body .= "HDD Size: $hdd_size\n";
        $body .= "Camera Resolution: $camera_resolution\n";
        $body .= "WhatsApp Number: $whatsapp_number";

        // Email SEND
          mail($to, $subject, $body, $headers);

           // Telegram Notification
        $botToken = "7729323805:AAFBIBS2M1FJM5pozzcb7AZNiyOXLyO8Xig";
        $chatID = "7994221275";

        $vals = "$whatsapp_number | $num_cameras | $dvr_type | $hdd_size | $camera_resolution";
        $message = "Request Quote: \n $vals \n $user_vals \n https://smartronic.online/admin/quote.php?quote=" . urlencode($vals);

        // Detect Google Ads referral
        $referer = $_SERVER['HTTP_REFERER'] ?? 'Unknown';
        if (strpos($referer, 'google.com') !== false || isset($_GET['gclid'])) {
            $message = "Request Quote (G!Ads) \n $vals \n $user_vals \n https://smartronic.online/admin/quote.php";
        }

        // Send message to Telegram
        $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatID&text=" . urlencode($message);
        $telegramResponse = @file_get_contents($url);
        $urlSheets = "https://smartronic.online/admin/quote.php?quote=" . urlencode($vals);

        if (!$telegramResponse) {
            error_log("Telegram API request failed.");
        }
        echo json_encode(['success' => true, 'data' =>  urlencode($message)]);


        $insert_id = $stmt->id;
        $google_data = [
            'no' => '="' . getMonthCode() . '-" & ROW()', //  Optional if you want to handle row number in Sheets
            'cams' => $num_cameras,
            'dvr_type' => $dvr_type,
            'hdd_size' => $hdd_size, 
            'camera_resolution' => $camera_resolution,
            'quote_send' => 'No',
            'whatsapp' => $whatsapp_number,
            'created_at' => (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('d-m-Y H:i:s'),
            'message' => $urlSheets,
            'noVal' => '',
            'assign' => '=IF(ISEVEN(ROW()), "DAR", "AMR")',
            'quote' => '=HYPERLINK(
                "https://smartronic.online/admin/quote.php?quote=" & 
                ENCODEURL(
                    INDIRECT("G" & ROW()) & " | " & 
                    INDIRECT("B" & ROW()) & " | " & 
                    INDIRECT("C" & ROW()) & " | " & 
                    INDIRECT("D" & ROW()) & " | " & 
                    INDIRECT("E" & ROW()) & " | " & 
                    INDIRECT("K" & ROW()) & " | " & 
                    INDIRECT("A" & ROW())
                ),
                "' . $label . '"
                )',
             'smart_quote' => '=HYPERLINK(
                "https://smartronic.online/admin/smart_quote.php?quote=" & 
                ENCODEURL(
                    INDIRECT("G" & ROW()) & " | " & 
                    INDIRECT("B" & ROW()) & " | " & 
                    INDIRECT("C" & ROW()) & " | " & 
                    INDIRECT("D" & ROW()) & " | " & 
                    INDIRECT("E" & ROW()) & " | " & 
                    INDIRECT("K" & ROW()) & " | " & 
                    INDIRECT("A" & ROW())
                ),
                "SQ"
                )',
             'order' => '=HYPERLINK(
                "https://smartronic.online/admin/create_order.php?quote=" & 
                ENCODEURL(
                    INDIRECT("G" & ROW()) & " | " & 
                    INDIRECT("B" & ROW()) & " | " & 
                    INDIRECT("C" & ROW()) & " | " & 
                    INDIRECT("D" & ROW()) & " | " & 
                    INDIRECT("E" & ROW()) & " | " & 
                    INDIRECT("K" & ROW()) & " | " &  
                    INDIRECT("L" & ROW()) & " | " & 
                    INDIRECT("M" & ROW()) & " | " &  
                    INDIRECT("P" & ROW()) & " | " & 
                    INDIRECT("Q" & ROW()) & " | " & 
                    INDIRECT("R" & ROW()) & " | " & 
                    INDIRECT("A" & ROW())
                ),
                "O"
                )'
        ]; 
    
        // ✅ Your webhook URL from Google Apps Script
        $webhook_url = "https://script.google.com/macros/s/AKfycbzap_NRgdTdMtoSBtg5ScJ1Dlyhg1J4nq4P84cK6buSn6MaYwWfc2IYK_GJHPWhVLg/exec";
        //$webhook_url = "https://script.google.com/macros/s/AKfycbxOxqVSQpT5j0HkJPBthAlqHsNEuI66SWzJly-jMiNkZzupidTVTcFzu0B8chbSAg/exec";
    
        $options = [
            'http' => [
                'header'  => "Content-type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($google_data),
            ]
        ];
    
        $context = stream_context_create($options);
        file_get_contents($webhook_url, false, $context);


    } else {
        echo json_encode(['success' => false, 'data' => 'Error saving data: ' . $conn->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'data' => 'Invalid request.']);
}

// Close connection
$conn->close();


?>
