<?php
$host = '127.0.0.1:3306';
$username = 'u398852039_smartronic';
$password = 'Chennai@40!';
$database = 'u398852039_smartronic';

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
$limit = 100;
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$sql = "SELECT * FROM wp_cctv_requirements";
if (!empty($search)) {
    $sql .= " WHERE ";
    $searchableColumns = ['whatsapp_number']; // adjust these
    $conditions = [];

    foreach ($searchableColumns as $col) {
        $conditions[] = "$col LIKE '%$search%'";
    }

    $sql .= implode(" OR ", $conditions);
}
$sql .= " LIMIT $offset, $limit";

$result = $conn->query($sql);
$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
