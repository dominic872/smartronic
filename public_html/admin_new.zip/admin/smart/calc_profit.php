<?php
ob_start();
require_once '../auth.php'; // Assuming we create auth.php in admin folder
error_reporting(E_ALL);
ini_set('display_errors', 1);
require '../config.php'; // contains $mysqli = new mysqli(...);
$error = '';


// Ensure error reporting won't expose sensitive data in production
error_reporting(0);

// Check if the cookie exists and has the right value
if (!isset($_COOKIE['auth_role']) || $_COOKIE['auth_role'] !== 'admin') {
    echo "No access";
    exit; // Stop processing the rest of the page
}

// If the user passes the check, the rest of your page code runs below...


// Set timezone to India
date_default_timezone_set('Asia/Kolkata');

echo '<!DOCTYPE html>
<html>
<head>
    <title>Profit Calculator</title>
    <style>
        body {
            font-family: "Segoe UI", sans-serif;
            background: #f8f9fa;
            padding: 30px;
        }
        h2 {
            color: #333;
        }
        form {
            margin-bottom: 30px;
        }
        input[type="date"], button {
            padding: 10px;
            margin-right: 10px;
            font-size: 16px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        .summary {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            gap: 40px;
            justify-content: start;
            font-size: 18px;
        }
        .card {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }

        .card.WIFI {
            background:rgb(255, 209, 209);
            
        }
        .card.NVR {
            background:rgb(238, 255, 209);
            
        }
        .card h4 {
            margin-top: 0;
            color: #007bff;
            display: inline-block;
            margin-bottom: 10px;
        }
        .label {
            font-weight: bold;
        }
        .label.profit {
            display: inline-block;
            background-color: rgb(124 202 124);
            color: #ffffff;
            padding: 0px 4px;
            border-radius: 2px;
            font-weight: 400;
            line-height: 1.2;
        }
    </style>
</head>
<body>

<h2>Profit Calculator 22</h2>
<form method="GET">
    <label>From: <input type="date" name="from" value="' . ($_GET['from'] ?? '') . '" required></label>
    <label>To: <input type="date" name="to" value="' . ($_GET['to'] ?? '') . '" required></label>
    <button type="submit">Calculate Profit</button>
</form>
';

if (isset($_GET['from']) && isset($_GET['to'])) {
    $fromDate = $_GET['from'];
    $toDate = $_GET['to'];

    try {
        $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u398852039_smartronic", "u398852039_smartronic", "Chennai@40!");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("<strong>Database connection failed:</strong> " . $e->getMessage());
    }

    function getPriceFromOptions(array $options, string $key): int {
        return $options[$key] ?? 0;
    }

    function calculatePoETotal(int $cameraCount): int {
        $prices = [8 => 1125, 4 => 825];
        $total = 0;
        $remaining = $cameraCount;
        while ($remaining > 8) {
            $total += $prices[8];
            $remaining -= 8;
        }
        if ($remaining > 0) {
            $total += $prices[($remaining <= 4 || $remaining === 4 || $remaining === 8) ? min($remaining, 4) : 8];
        }
        return $total;
    }

    function getChannel(int $numCameras): int {
        foreach ([4, 8, 16, 32] as $ch) {
            if ($numCameras <= $ch) return $ch;
        }
        return 32;
    }

    $hddOptions = [
        '500GB' => 1000, '1TB' => 2750, '2TB' => 3650, '4TB (2YR)' => 5250,
        '500 GB (1YR)' => 850, '1TB (1YR)' => 1950, '1TB (3YR)' => 3600,
        '2TB (1YR)' => 2850, '2TB (3YR)' => 4050, '3TB (1YR)' => 3250,
        '4TB (1YR)' => 5250, '4TB (3YR)' => 6650
    ];

    $recorderOptions = [
        'DVR 2 MP 4CH' => 1950, 'DVR 2 MP 8CH' => 2850, 'DVR 2 MP 16CH' => 4950, 'DVR 2 MP 32CH' => 17750,
        'DVR 5 MP 4CH' => 2780, 'DVR 5 MP 8CH' => 4500, 'DVR 5 MP 16CH' => 10000, 'DVR 5 MP 32CH' => 21500,
        'NVR 4CH' => 2850, 'NVR 8CH' => 3390, 'NVR 16CH' => 4950, 'NVR 32CH' => 11050
    ];

    $cameraOptions = [
        'DVR 2 MP' => 825, 'DVR 5 MP' => 1150, 'NVR 2 MP' => 2500, 'NVR 5 MP' => 2650
    ];

    $sql = "SELECT * 
            FROM orders 
            WHERE date BETWEEN :from AND :to 
            AND price IS NOT NULL 
            AND (record_status IS NULL OR record_status != 'DELETED')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['from' => $fromDate, 'to' => $toDate]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $totalOrders = 0;
    $totalPaid = 0;
    $totalProfit = 0;

    foreach ($orders as $order) {
        $numCams = (int) $order['quantity'];
        $dvrType = strtoupper(trim($order['product']));
        $hddSize = strtoupper(trim($order['storage']));
        $resolution = strtoupper(trim($order['resolution']));
        $customerPrice = floatval(str_replace(',', '', $order['price']));

        $channel = getChannel($numCams);
        $recorderKey = $dvrType === 'DVR' ? "$dvrType $resolution {$channel}CH" : "$dvrType {$channel}CH";
        $cameraKey = "$dvrType $resolution";

        $cameraUnitPrice = getPriceFromOptions($cameraOptions, $cameraKey);
        $cameraTotal = $cameraUnitPrice * $numCams;
        $recorderPrice = getPriceFromOptions($recorderOptions, $recorderKey);
        $hddPrice = getPriceFromOptions($hddOptions, $hddSize);
        $poePrice = ($dvrType === 'NVR') ? calculatePoETotal($numCams) : 0;
        $cablePrice = ($dvrType === 'DVR') ? 1000 : 1600;
        $smpsPrice = ($dvrType === 'DVR') ? (($numCams > 8) ? 750 : 400) : 0;
        $accessories = ($numCams * 80) + $cablePrice;

        $subtotal = $hddPrice + $cameraTotal + $recorderPrice + $poePrice + $smpsPrice + $accessories;
        $gst = $subtotal * 0.18;
        $vendorCost = $subtotal + $gst;
        if ($dvrType != 'WIFI') {
             $profit = $customerPrice - $vendorCost;
        } else {
             $profit = $customerPrice * .33;
        }
       

        $totalOrders++;
        $totalPaid += $customerPrice;
        $totalProfit += $profit;

        echo "<div class='card $dvrType'>";
        echo "<h4>{$order['name']} ({$order['idno']})</h4> ";
        echo " <span class='profit label'> ₹" . number_format($profit) . "</span>";
        echo "<div><span class='label'>Phone:</span> {$order['phone']} | <span class='label'>Area:</span> {$order['area']} | <span class='label'>Owner:</span> {$order['Owner']}</div>";
        echo "<div><span class='label'>Product:</span> $dvrType | <span class='label'>Resolution:</span> $resolution | <span class='label'>Storage:</span> $hddSize</div>";
        echo "<div><span class='label'>Quantity:</span> $numCams | <span class='label'>Paid:</span> ₹" . number_format($customerPrice) . "</div>";
        echo "<div><span class='label'>Vendor Cost:</span> ₹" . number_format($vendorCost) . "</div>";
        echo "</div>";
    }

    if ($totalOrders > 0) {
        echo "<div class='summary'>
            <div>🧾 <strong>Total Orders:</strong> $totalOrders</div>
            <div>💰 <strong>Total Paid:</strong> ₹" . number_format($totalPaid) . "</div>
            <div>📈 <strong>Total Profit:</strong> ₹" . number_format($totalProfit) . "</div>
        </div>";
    } else {
        echo "<p>No orders found in this date range.</p>";
    }
}

echo '</body></html>';
