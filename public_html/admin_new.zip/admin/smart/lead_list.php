<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Scroll & Filter</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
    }
    #searchBar {
      padding: 16px;
      background: #f1f1f1;
      position: sticky;
      top: 0;
      z-index: 1;
      display: flex;
      justify-content: center;
      gap: 10px;
    }
    #searchInput {
      padding: 8px;
      font-size: 16px;
      width: 300px;
    }
    #clearBtn {
      padding: 8px 12px;
      cursor: pointer;
    }
    #container {
      max-width: 800px;
      margin: auto;
      padding: 20px;
    }
    .row-item {
      background: #f9f9f9;
      margin-bottom: 12px;
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
      animation: fadeIn 0.4s ease;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    #top-sentinel, #bottom-sentinel {
      height: 1px;
    }
    #status {
      text-align: center;
      padding: 10px;
      color: #666;
    }
  </style>
</head>
<body>
  <div id="searchBar">
    <input type="text" id="searchInput" placeholder="Search name, location, type..." />
    <button id="clearBtn">Clear</button>
  </div>

  <div id="container">
    
    <div id="top-sentinel"></div>
    
    <!-- rows go here -->
    <div id="bottom-sentinel"></div>
  </div>

  <div id="status">Loading...</div>

  <script>
    let lastScrollDirection = 'down';

    const container = document.getElementById('container');
    const topSentinel = document.getElementById('top-sentinel');
    const bottomSentinel = document.getElementById('bottom-sentinel');
    const searchInput = document.getElementById('searchInput');
    const clearBtn = document.getElementById('clearBtn');
    const status = document.getElementById('status');

    let offsetStart = 0;
    let offsetEnd = 0;
    let isLoading = false;
    let searchQuery = '';
    const PAGE_SIZE = 100;
    const MAX_ROWS = 200;

    function createRow(row) {
      const div = document.createElement('div');
      div.className = 'row-item';
      div.innerHTML = Object.entries(row)
        .map(([k, v]) => `<strong>${k}:</strong> ${v}`)
        .join('<br>');
      return div;
    }
function fetchRows(direction = 'down') {
  if (isLoading) return;
  isLoading = true;
  status.innerText = 'Loading...';

  let fetchOffset;
  if (direction === 'down') {
    fetchOffset = offsetEnd;
  } else {
    fetchOffset = Math.max(0, offsetStart - PAGE_SIZE);
  }

  fetch(`lead_fetch.php?offset=${fetchOffset}&search=${encodeURIComponent(searchQuery)}`)
    .then(res => {
      if (!res.ok) throw new Error("Server error");
      return res.json();
    })
    .then(data => {
      if (!Array.isArray(data) || data.length === 0) {
        status.innerText = 'No more records.';
        isLoading = false;
        return;
      }

      if (direction === 'down') {
        data.forEach(row => {
          const el = createRow(row);
          container.insertBefore(el, bottomSentinel);
          offsetEnd++;
        });
      } else {
// Prepend in reverse order to maintain original sequence
for (let i = data.length - 1; i >= 0; i--) {
  const rowEl = createRow(data[i]);
  container.insertBefore(rowEl, topSentinel.nextSibling);
  container.scrollTop += rowEl.offsetHeight + 12;
}
offsetStart = Math.max(0, offsetStart - data.length);

      }

      trimExcessRows();
      status.innerText = '';
      isLoading = false;
    })
    .catch(err => {
      console.error(err);
      status.innerText = 'Error loading records.';
      isLoading = false;
    });
}

function trimExcessRows() {
  const items = Array.from(container.querySelectorAll('.row-item'));
  if (items.length <= MAX_ROWS) return;

  const extra = items.length - MAX_ROWS;

  if (offsetEnd - offsetStart > MAX_ROWS) {
    if (lastScrollDirection === 'down') {
      // Remove from top
      for (let i = 0; i < extra; i++) {
        items[i].remove();
        offsetStart++;
      }
    } else {
      // Remove from bottom
      for (let i = 0; i < extra; i++) {
        items[items.length - 1 - i].remove();
        offsetEnd--;
      }
    }
  }
}



    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          if (entry.target.id === 'bottom-sentinel') {
        lastScrollDirection = 'down';
        fetchRows('down');
      }
      if (entry.target.id === 'top-sentinel') {
        lastScrollDirection = 'up';
        fetchRows('up');
      }
        }
      });
    }, {
        root: null,
  rootMargin: '200px 0px',  // 👈 Load data BEFORE reaching edge
  threshold: 0.01
    });

    observer.observe(topSentinel);
    observer.observe(bottomSentinel);

    searchInput.addEventListener('input', () => {
      searchQuery = searchInput.value.trim();
      resetStateAndReload();
    });

    clearBtn.addEventListener('click', () => {
      searchInput.value = '';
      searchQuery = '';
      resetStateAndReload();
    });

    function resetStateAndReload() {
      offsetStart = 0;
      offsetEnd = 0;
      container.querySelectorAll('.row-item').forEach(el => el.remove());
      fetchRows('down');
    }

    // Load initial
    offsetStart = 0;
    

    fetchRows('down');
  </script>
</body>
</html>
