// Integration module: WhatsApp, Quote API, Google Places autocomplete
(function(){
  async function sendToWhatsapp(e, ev){
    if (e && e.preventDefault) e.preventDefault();
    const technicianName = ev.technician || '';
    try {
      const res = await fetch('../users.json');
      const users = await res.json();
      const user = users.find(u => (u.name||'').toLowerCase() === technicianName.toLowerCase());
      const phone = user ? user.phone : '91888431000';
      const message = `
*Name: ${ev.name || ''}*
*Phone: ${ev.phone || ''}*
*ID*: ${ev.id || ''}\n
----------------------\n
*${ev.type || ''} | Resolution*: ${ev.resolution || ''}*
*Total Cams*: ${ev.total || ''} | B ${ev.bullets || ''} | D ${ev.dome || ''} | *HDD*: ${ev.hdd || ''}
*Monitor*: ${ev.monitor || 'No'} | *Rack*: ${ev.rack || 'No'}\n
----------------------\n
*Location*: ${ev.location || ''}
*Date*: ${ev.date || ''}
*Time*: ${ev.time || ''}
*Map*: ${ev.map || ''}
`;      const encodedMsg = encodeURIComponent(message.trim());
      const waUrl = `https://wa.me/${phone}?text=${encodedMsg}`;
      window.open(waUrl, '_blank');
    } catch (error) {
      console.error('Error loading users.json or matching technician:', error);
      alert('Could not send message. Please check technician name or users.json file.');
    }
  }
  window.sendToWhatsapp = sendToWhatsapp;

  function getQuoteDetails(installDetails){
    const requestData = {
      whatsapp_number: '88888888',
      num_cameras: installDetails.cams,
      dvr_type: installDetails.type,
      hdd_size: installDetails.hdd,
      camera_resolution: installDetails.resolution
    };
    fetch('/admin/quote_api.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(requestData)
    })
      .then(response => response.json())
      .then(data => {
        const el = document.getElementById('result');
        if (el) el.textContent = `\n        🎁 Final (20% Off): ₹${data.final_total} \n\n        ✅ Final Limited Profit Total: ₹${data.final_limited_profit}\n        `.trim();
      })
      .catch(err => {
        console.error('Error calling quote API:', err);
        const el = document.getElementById('result'); if (el) el.textContent = 'Error fetching quote.';
      });
  }
  window.getQuoteDetails = getQuoteDetails;

  let locationAutocompleteInitialized = false;
  function initLocationAutocomplete(){
    if (locationAutocompleteInitialized) return;
    const input = document.getElementById('location'); if (!input) return;
    const options = {
      types: ['geocode'], componentRestrictions: { country: 'in' }, fields: ['formatted_address'],
      bounds: new google.maps.LatLngBounds(new google.maps.LatLng(12.80, 77.40), new google.maps.LatLng(13.20, 77.80)),
      strictBounds: false
    };
    const autocomplete = new google.maps.places.Autocomplete(input, options);
    autocomplete.addListener('place_changed', () => { const place = autocomplete.getPlace(); if (place && place.formatted_address) input.value = place.formatted_address; });
    locationAutocompleteInitialized = true;
  }
  window.initLocationAutocomplete = initLocationAutocomplete;

  window.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    if (!id) return;
    fetch('installs_api.php')
      .then(res => res.json())
      .then(data => {
        const exists = data.find(r => r.id === id);
        if (exists) { alert(`Record already exists for date: ${exists.date}`); }
        else {
          const formData = {
            id: params.get('id') || '', name: params.get('name') || '', cams: params.get('cams') || '', bullets: '', dome: '', hdd: (params.get('hdd') || '').replace(/\s+/g, ''), monitor: '', type: params.get('type') || '', location: params.get('location') || '', time: '', date: params.get('date') || '', owner: params.get('owner') || '', technician: '', helper: '', resolution: params.get('resolution') || '', map: params.get('map') || ''
          };
          if (typeof window.openForm === 'function') window.openForm(formData);
        }
      });
  });
})();
