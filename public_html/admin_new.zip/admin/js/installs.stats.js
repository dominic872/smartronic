// Stats and Owner Modal module
// Requires: installs.utils.js (escapeHtml), and relies on global allInstalls, currentMonday

(function(){
  let lastWeekStats = null;
  let lastMonthStats = null;
  let lastTechWeek = [];
  let lastTechMonth = [];
  let lastTechTwoPerDay = [];
  let lastTechTwoPerDayDates = [];
  let lastWeekTotalCount = 0;
  let lastMonthTotalCount = 0;
  let lastMonthTotalCams = 0;

  let statsBtn = null;
  let weeksToggleBtn = null; // referenced by toolbar if present
  let toolbar = null;
  let toolbarRight = null;
  const monthLabel = document.getElementById('monthLabel');

  function ensureToolbar(){
    if (toolbar && toolbarRight) return;
    toolbar = document.createElement('div');
    toolbar.id = 'calendarToolbar';
    toolbar.className = 'calendar-toolbar';
    const left = document.createElement('div'); left.className = 'toolbar-left';
    toolbarRight = document.createElement('div'); toolbarRight.className = 'toolbar-right';
    toolbar.appendChild(left); toolbar.appendChild(toolbarRight);
    const calendarEl = document.querySelector('.calendar');
    const weekdaysEl = calendarEl ? calendarEl.querySelector('.weekdays') : null;
    if (calendarEl) {
      if (weekdaysEl) calendarEl.insertBefore(toolbar, weekdaysEl);
      else calendarEl.insertBefore(toolbar, calendarEl.firstChild);
    }
    if (left && monthLabel) left.appendChild(monthLabel);
  }

  function ensureOwnerStatsButton(){
    ensureToolbar();
    if (statsBtn) return;
    statsBtn = document.createElement('button');
    statsBtn.type = 'button';
    statsBtn.className = 'owner-stats-btn';
    statsBtn.textContent = 'Show Stats';
    statsBtn.onclick = openOwnerStatsModal;
    toolbarRight.appendChild(statsBtn);
  }

  function openOwnerStatsModal() {
    if (!document.getElementById('stats-backdrop')) {
      const backdrop = document.createElement('div');
      backdrop.id = 'stats-backdrop';
      backdrop.className = 'modal-backdrop';
      backdrop.addEventListener('click', closeOwnerStatsModal);
      const wrap = document.createElement('div');
      wrap.id = 'stats-modal';
      wrap.className = 'modal-wrap';
      wrap.setAttribute('role', 'dialog');
      wrap.setAttribute('aria-modal', 'true');
      wrap.setAttribute('aria-label', 'Show Stats');
      wrap.innerHTML = `
        <div class="modal-card">
          <div class="modal-head">
            <h3>Stats</h3>
            <button class="modal-close" aria-label="Close" title="Close">&times;</button>
          </div>
          <div class="modal-body" id="stats-body"></div>
        </div>
      `;
      document.body.appendChild(backdrop);
      document.body.appendChild(wrap);
      wrap.querySelector('.modal-close').addEventListener('click', closeOwnerStatsModal);
      document.addEventListener('keydown', escCloseStats, { once: true });
    }
    const body = document.getElementById('stats-body');
    if (!lastWeekStats || !lastMonthStats) body.innerHTML = '<p>No data yet.</p>';
    else body.innerHTML = buildStatsHTML(lastWeekStats, lastMonthStats);
    document.body.classList.add('modal-open');
  }
  function closeOwnerStatsModal(){
    const b = document.getElementById('stats-backdrop');
    const m = document.getElementById('stats-modal');
    if (b) b.remove();
    if (m) m.remove();
    document.body.classList.remove('modal-open');
  }
  function escCloseStats(e){ if (e.key === 'Escape') closeOwnerStatsModal(); }

  function techDatesTable(title, rows) {
    const fmt = (iso) => typeof window.formatDateDisplay === 'function' ? window.formatDateDisplay(iso) : iso;
    return `
      <div class="stats-card">
        <div class="stats-card-title">${title}</div>
        <div class="tech-table-wrap">
          <table class="tech-table tech-dates-table">
            <thead>
              <tr>
                <th>Technician</th>
                <th class="num">Days with exactly 2 installs</th>
                <th>Dates</th>
              </tr>
            </thead>
            <tbody>
              ${ rows.length
                  ? rows.map(r => `
                      <tr>
                        <td>${escapeHtml(r.tech)}</td>
                        <td class="num">${r.dates.length}</td>
                        <td><div class="date-chip-row">${r.dates.map(d => `<span class="date-chip">${fmt(d)}</span>`).join('')}</div></td>
                      </tr>
                    `).join('')
                  : `<tr><td colspan="3" class="muted">No technician has exactly two installs on any day this month.</td></tr>`
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  function buildStatsHTML(week, month){
    const owners = ['DAR','AMR','DOM'];
    const types = ['WIFI','DVR','NVR'];
    const summary = `
      <div class="stats-summary">
        <div class="summary-pill"><span class="label">Weekly installs</span><span class="value">${lastWeekTotalCount}</span></div>
        <div class="summary-pill"><span class="label">Monthly installs</span><span class="value">${lastMonthTotalCount}</span></div>
        <div class="summary-pill"><span class="label">Cameras this month</span><span class="value">${lastMonthTotalCams}</span></div>
      </div>
    `;
    const ownerCard = (title, data) => `
      <div class="stats-card">
        <div class="stats-card-title">${title}</div>
        <div class="stats-grid">
          ${owners.map(o => `
            <div class="owner-block">
              <div class="owner-name">${o}</div>
              <div class="owner-row">
                ${types.map(t => `
                  <div class="metric">
                    <div class="metric-num">${(data[o] && data[o][t]) ? data[o][t] : 0}</div>
                    <div class="metric-label">${t}</div>
                  </div>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    const techTable = (title, rows, showCams=false) => `
      <div class="stats-card">
        <div class="stats-card-title">${title}</div>
        <div class="tech-table-wrap">
          <table class="tech-table">
            <thead>
              <tr>
                <th>Technician</th>
                <th>Installs</th>
                ${showCams ? '<th>Cams</th>' : ''}
              </tr>
            </thead>
            <tbody>
              ${ rows.length
                  ? rows.map(r => `
                      <tr>
                        <td>${escapeHtml(r.tech)}</td>
                        <td class="num">${r.count ?? r.daysWithTwo}</td>
                        ${showCams ? `<td class="num">${r.cams ?? 0}</td>` : ''}
                      </tr>
                    `).join('')
                  : `<tr><td colspan="${showCams?3:2}" class="muted">No data</td></tr>`
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
    return `
      ${summary}
      ${ownerCard('This week (Owners)', week)}
      ${ownerCard('This month (Owners)', month)}
      ${techTable('This week (Technicians)', lastTechWeek, true)}
      ${techTable('This month (Technicians)', lastTechMonth, true)}
      ${techTable('Two-in-a-day this month (Technicians)', lastTechTwoPerDay, false)}
      ${techDatesTable('Two-in-a-day dates this month (Technicians)', lastTechTwoPerDayDates)}
    `;
  }

  function updateStats(){
    if (!Array.isArray(window.allInstalls)) return;
    const allInstalls = window.allInstalls;
    const today = new Date();
    const currentWeekStart = new Date(window.currentMonday);
    currentWeekStart.setHours(0,0,0,0);
    const currentWeekEnd = new Date(currentWeekStart);
    currentWeekEnd.setDate(currentWeekStart.getDate() + 6);
    currentWeekEnd.setHours(23,59,59,999);

    const displayedMonthStart = new Date(currentWeekStart.getFullYear(), currentWeekStart.getMonth(), 1);
    displayedMonthStart.setHours(0,0,0,0);
    const displayedMonthEnd = new Date(currentWeekStart.getFullYear(), currentWeekStart.getMonth() + 1, 0);
    displayedMonthEnd.setHours(23,59,59,999);

    const weekStats = { DAR:{WIFI:0,DVR:0,NVR:0}, AMR:{WIFI:0,DVR:0,NVR:0}, DOM:{WIFI:0,DVR:0,NVR:0} };
    const monthStats = { DAR:{WIFI:0,DVR:0,NVR:0}, AMR:{WIFI:0,DVR:0,NVR:0}, DOM:{WIFI:0,DVR:0,NVR:0} };

    allInstalls.forEach(install => {
      if (!install.date || !install.owner) return;
      const d = new Date(install.date); d.setHours(12,0,0,0);
      if (d >= currentWeekStart && d <= currentWeekEnd) {
        if (weekStats[install.owner] && weekStats[install.owner][install.type] !== undefined) weekStats[install.owner][install.type]++;
      }
      if (d >= displayedMonthStart && d <= displayedMonthEnd) {
        if (monthStats[install.owner] && monthStats[install.owner][install.type] !== undefined) monthStats[install.owner][install.type]++;
      }
    });

    const setText = (id, html) => { const el = document.getElementById(id); if (el) el.innerHTML = html; };
    setText('weekDAR', `<div class="number">${weekStats.DAR.WIFI}</div>WiFi<div class="number">${weekStats.DAR.DVR}</div>DVR<div class="number">${weekStats.DAR.NVR}</div>NVR<br>DAR`);
    setText('weekAMR', `<div class="number">${weekStats.AMR.WIFI}</div>WiFi<div class="number">${weekStats.AMR.DVR}</div>DVR<div class="number">${weekStats.AMR.NVR}</div>NVR<br>AMR`);
    setText('weekDOM', `<div class="number">${weekStats.DOM.WIFI}</div>WiFi<div class="number">${weekStats.DOM.DVR}</div>DVR<div class="number">${weekStats.DOM.NVR}</div>NVR<br>DOM`);

    setText('monthDAR', `<div class="number">${monthStats.DAR.WIFI}</div>WiFi<div class="number">${monthStats.DAR.DVR}</div>DVR<div class="number">${monthStats.DAR.NVR}</div>NVR<br>DAR`);
    setText('monthAMR', `<div class="number">${monthStats.AMR.WIFI}</div>WiFi<div class="number">${monthStats.AMR.DVR}</div>DVR<div class="number">${monthStats.AMR.NVR}</div>NVR<br>AMR`);
    setText('monthDOM', `<div class="number">${monthStats.DOM.WIFI}</div>WiFi<div class="number">${monthStats.DOM.DVR}</div>DVR<div class="number">${monthStats.DOM.NVR}</div>NVR<br>DOM`);

    const weekTotal = weekStats.DAR.WIFI + weekStats.DAR.DVR + weekStats.DAR.NVR + weekStats.AMR.WIFI + weekStats.AMR.DVR + weekStats.AMR.NVR + weekStats.DOM.WIFI + weekStats.DOM.DVR + weekStats.DOM.NVR;
    const dayOfWeek = (today.getDay() === 0 ? 7 : today.getDay());
    const projectedWeek = Math.round((weekTotal / dayOfWeek) * 7);
    const thisWeekEl = document.getElementById('thisWeek'); if (thisWeekEl) thisWeekEl.textContent = `${weekTotal} (~${projectedWeek} / w)`;

    const totalSoFar = monthStats.DAR.WIFI + monthStats.DAR.DVR + monthStats.DAR.NVR + monthStats.AMR.WIFI + monthStats.AMR.DVR + monthStats.AMR.NVR + monthStats.DOM.WIFI + monthStats.DOM.DVR + monthStats.DOM.NVR;
    const currentDay = today.getDate();
    const totalDays = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
    const projected = Math.round((totalSoFar / currentDay) * totalDays);
    const thisMonthEl = document.getElementById('thisMonth'); if (thisMonthEl) thisMonthEl.textContent = `${totalSoFar} (~ ${projected} / m)`;

    lastWeekStats = JSON.parse(JSON.stringify(weekStats));
    lastMonthStats = JSON.parse(JSON.stringify(monthStats));
    lastWeekTotalCount = weekTotal;
    lastMonthTotalCount = totalSoFar;

    lastMonthTotalCams = allInstalls.reduce((sum, inst) => {
      if (!inst.date) return sum;
      const d = new Date(inst.date); d.setHours(12,0,0,0);
      if (d >= displayedMonthStart && d <= displayedMonthEnd) {
        const c = parseInt(inst.cams, 10);
        return sum + (isNaN(c) ? 0 : c);
      }
      return sum;
    }, 0);

    const normTech = (t) => (t && String(t).trim()) || 'Unassigned';
    const weekTechCounts = {}; const monthTechCounts = {}; const monthTechDayCounts = {};

    allInstalls.forEach(inst => {
      if (!inst || !inst.date) return;
      const tech = normTech(inst.technician);
      const d = new Date(inst.date); d.setHours(12,0,0,0);
      const cams = parseInt(inst.cams, 10) || 0;
      if (d >= currentWeekStart && d <= currentWeekEnd) {
        if (!weekTechCounts[tech]) weekTechCounts[tech] = { installs: 0, cams: 0 };
        weekTechCounts[tech].installs++; weekTechCounts[tech].cams += cams;
      }
      if (d >= displayedMonthStart && d <= displayedMonthEnd) {
        if (!monthTechCounts[tech]) monthTechCounts[tech] = { installs: 0, cams: 0 };
        monthTechCounts[tech].installs++; monthTechCounts[tech].cams += cams;
        const iso = inst.date;
        if (!monthTechDayCounts[tech]) monthTechDayCounts[tech] = {};
        monthTechDayCounts[tech][iso] = (monthTechDayCounts[tech][iso] || 0) + 1;
      }
    });

    const monthTwoPerDay = {};
    Object.entries(monthTechDayCounts).forEach(([tech, byDate]) => {
      let daysWithTwo = 0;
      Object.values(byDate).forEach(n => { if (n === 2) daysWithTwo++; });
      if (daysWithTwo > 0) monthTwoPerDay[tech] = daysWithTwo;
    });

    lastTechTwoPerDayDates = [];
    Object.entries(monthTechDayCounts).forEach(([tech, byDate]) => {
      const dates = Object.entries(byDate).filter(([,n]) => n === 2).map(([iso]) => iso).sort();
      if (dates.length) lastTechTwoPerDayDates.push({ tech, dates });
    });
    lastTechTwoPerDayDates.sort((a,b) => b.dates.length - a.dates.length);

    const sortDesc = (a, b) => b.installs - a.installs;
    const sortDescTwo = (a, b) => b.daysWithTwo - a.daysWithTwo;

    lastTechWeek = Object.entries(weekTechCounts).map(([tech,v]) => ({ tech, count: v.installs, cams: v.cams })).sort(sortDesc);
    lastTechMonth = Object.entries(monthTechCounts).map(([tech,v]) => ({ tech, count: v.installs, cams: v.cams })).sort(sortDesc);
    lastTechTwoPerDay = Object.entries(monthTwoPerDay).map(([tech,daysWithTwo]) => ({ tech, daysWithTwo })).sort(sortDescTwo);

    ensureOwnerStatsButton();
  }

  // Expose globals used by calendar
  window.updateStats = updateStats;
  window.openOwnerStatsModal = openOwnerStatsModal;
  window.closeOwnerStatsModal = closeOwnerStatsModal;
})();
